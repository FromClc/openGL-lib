// Demo.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <GL/glut.h>              // glut.h includes gl.h and glu.h already
#include <windows.h>
#include <math.h>

void draw_origin()
{
	glColor3f(1.0, 0.0, 0.0);

	glBegin(GL_LINES);

	glVertex3f(-1.0, 0.0, 0.0);
	glVertex3f( 1.0, 0.0, 0.0);

	glVertex3f( 0.0, -1.0, 0.0);
	glVertex3f( 0.0,  1.0, 0.0);

	glEnd();
}

void draw_polygon()
{

glBegin(GL_QUADS); 

glNormal3f( 0.0F, 0.0F, 1.0F);  
glVertex3f( 3.0f, 1.0f, 0.0f);  
glVertex3f( 7.0f, 1.0f, 0.0f);  
glVertex3f( 7.0f, 3.0f, 0.0f);  
glVertex3f( 3.0f, 3.0f, 0.0f);  
 
glEnd();
}


void display()
{
	glClear(GL_COLOR_BUFFER_BIT); // Clear the color buffer

    draw_origin();
	glColor3f(0.0, 0.0, 1.0);
    draw_polygon();
    glColor3f(1.0, 1.0, 0.0);
	glPushMatrix();
    
	//
	glTranslated(3.0, 1.0, 0.0);
	glScalef(1.0, 1.5, 1.0);
	glRotatef(90,0,0,1);
	glTranslated(-3.0,-1.0,0.0);
	draw_polygon();

	glPopMatrix();
	
	glFlush();                    //Force the processor to draw immediately
}

void myinit()
{
	glClearColor( 0.0, 0.0, 0.0, 0.0);  //Set the clear color to black

	// Specify the domain of the viewing window
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	// The para are: (left, right, bottom, top)
	gluOrtho2D(-8.0, 8.0, -8.0, 8.0); 
	glMatrixMode(GL_MODELVIEW);
}


int _tmain(int argc, _TCHAR* argv[])
{
			// Initialize GLUT function callings
	glutInit( &argc, (char **)argv);          

	// Set window size (width, height) in number of pixels  	
	glutInitWindowSize( 800, 800);   

	// Specify window position, from the left and top of the screen, in numbers of pixels 
	glutInitWindowPosition( 200, 100);        

	// Specify a window creation event 
	glutCreateWindow( "A Yellow Quad."); 

	//Specify the drawing function, called when the window is created or re-drew 
	glutDisplayFunc( display);         

	myinit();		      //Invoke this function for initializaton	

	glutMainLoop();       // Enter the event processing loop

	return 0;             // ANSI C requires main() to return an int

	 
}

